from basicImportInfo import *

UserInfo = None

class ProfileWindow(QWidget):
    switchToMenuWindow, switchToWorkoutTableWindow = pyqtSignal(str), pyqtSignal(str)

    def __init__(self, uName):
        QWidget.__init__(self)

        self.setWindowTitle('Profile Config')
        self.setStyleSheet("background-color: gray")

        layout = QGridLayout()
        global UserInfo
        UserInfo = uName

        self.title = QLabel("Profile Config")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("""
        QLabel {
            font-size: 45px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 1100px;
            
            border: 3px solid;
            border-radius: 25%;

            margin-top: 1px;
            
            background-color: lightgray;
        }
        
        """)
        
        self.labelsLabel = QLabel("Inputs")
        self.labelsLabel.setAlignment(Qt.AlignCenter)
        self.labelsLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.currentLabel = QLabel("Current Info")
        self.currentLabel.setAlignment(Qt.AlignCenter)
        self.currentLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)


        self.newInput = QLabel("Updated Info")
        self.newInput.setAlignment(Qt.AlignCenter)
        self.newInput.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)


        query = selectFromTable(conn, dataBases[0][1], fromWhere={"userName": uName}, colNum=5)[0]
        print(query, uName)
        passW, fName, lName, apiKey = query[1], query[2], query[3], query[4]
        print(passW, fName, lName, apiKey)

        # Password
        self.currentPasswordLabel = QLabel(passW)
        self.currentPasswordLabel.setAlignment(Qt.AlignCenter)
        self.currentPasswordLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.passwordLabel = QLabel("Password")
        self.passwordLabel.setAlignment(Qt.AlignCenter)
        self.passwordLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.newPasswordInput = QLineEdit()
        self.newPasswordInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;
            
            border: 3px solid;
            border-radius: 25%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        

        # First Name
        self.currentFNameLabel = QLabel(fName)
        self.currentFNameLabel.setAlignment(Qt.AlignCenter)
        self.currentFNameLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.fNameLabel = QLabel("First Name")
        self.fNameLabel.setAlignment(Qt.AlignCenter)
        self.fNameLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.newFNameInput = QLineEdit()
        self.newFNameInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;
            
            border: 3px solid;
            border-radius: 25%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        

        # Last Name
        self.currentLNameLabel = QLabel(lName)
        self.currentLNameLabel.setAlignment(Qt.AlignCenter)
        self.currentLNameLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.lNameLabel = QLabel("Last Name")
        self.lNameLabel.setAlignment(Qt.AlignCenter)
        self.lNameLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.newLNameInput = QLineEdit()
        self.newLNameInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;
            
            border: 3px solid;
            border-radius: 25%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        

        # APIKEY?
        self.currentApiKeyLabel = QLabel(apiKey)
        self.currentApiKeyLabel.setAlignment(Qt.AlignCenter)
        self.currentApiKeyLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.apiKeyLabel = QLabel("API Key")
        self.apiKeyLabel.setAlignment(Qt.AlignCenter)
        self.apiKeyLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;

            border: 3px solid;
            border-radius: 25%;

            background-color: lightgray;
        }
        """)

        self.newApiKeyInput = QLineEdit()
        self.newApiKeyInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 400px;
            max-width: 400px;
            
            border: 3px solid;
            border-radius: 25%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        
        
        self.backButton = QPushButton('Back To Main Menu')
        self.backButton.clicked.connect(self.goToMainMenuWindow)
        self.backButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 400px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)

        self.workoutTableButton = QPushButton('Workout Table')
        self.workoutTableButton.clicked.connect(self.goToWorkoutTableWindow)
        self.workoutTableButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 400px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)

        self.submitButton = QPushButton('Submit')
        self.submitButton.clicked.connect(self.goToSubmit)
        self.submitButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 400px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)


        self.addToLayout = [(self.title, 0, 0, 1, 3),

                            (self.labelsLabel, 1, 0, 1, 1), (self.currentLabel, 1, 1, 1, 1), (self.newInput, 1, 2, 1, 1),
                            (self.passwordLabel, 2, 0, 1, 1), (self.currentPasswordLabel, 2, 1, 1, 1), (self.newPasswordInput, 2, 2, 1, 1),
                            (self.fNameLabel, 3, 0, 1, 1), (self.currentFNameLabel, 3, 1, 1, 1), (self.newFNameInput, 3, 2, 1, 1),
                            (self.lNameLabel, 4, 0, 1, 1), (self.currentLNameLabel, 4, 1, 1, 1), (self.newLNameInput, 4, 2, 1, 1),
                            (self.apiKeyLabel, 5, 0, 1, 1), (self.currentApiKeyLabel, 5, 1, 1, 1),  (self.newApiKeyInput, 5, 2, 1, 1),

                            (self.backButton, 6, 0, 1, 1), (self.workoutTableButton, 6, 1, 1, 1), (self.submitButton, 6, 2, 1, 1)]
        for x in self.addToLayout:
            layout.addWidget(x[0], x[1], x[2], x[3], x[4])
        self.setLayout(layout)
    
    def goToSubmit(self):
        print("Updating")
        pass


    def goToMainMenuWindow(self):
        global UserInfo
        self.switchToMenuWindow.emit(UserInfo)

    def goToWorkoutTableWindow(self):
        self.switchToWorkoutTableWindow.emit(UserInfo)


class WorkoutTableWindow(QWidget):
    switchToMenuWindow, switchToProfileWindow = pyqtSignal(str), pyqtSignal(str)

    def __init__(self, uName):
        QWidget.__init__(self)

        self.setWindowTitle('Person Database Configuration')
        self.setStyleSheet("background-color: gray")

        layout = QGridLayout()
        global UserInfo
        UserInfo = uName

        self.title = QLabel("Workout Table")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("""
        QLabel {
            font-size: 45px;
            font: bold italic "Times New Roman";

            min-height: 50px;
            max-height: 75px;
            min-width: 1100px;
            
            border: 3px solid;
            border-radius: 25%;

            margin-top: 1px;
            
            background-color: lightgray;
        }
        
        """)
        
        # dateID
        self.dateIDLabel = QLabel("Date ID")
        self.dateIDLabel.setAlignment(Qt.AlignCenter)
        self.dateIDLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 30px;
            max-height: 40px;
            min-width: 200px;

            border: 3px solid;
            border-radius: 20%;

            background-color: lightgray;
        }
        """)

        self.dateIDInput = QLineEdit()
        self.dateIDInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 20px;
            max-height: 30px;
            min-width: 200px;
            
            border: 3px solid;
            border-radius: 10%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        
        
        # exName
        self.exNameLabel = QLabel("Ex Name")
        self.exNameLabel.setAlignment(Qt.AlignCenter)
        self.exNameLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 30px;
            max-height: 40px;
            min-width: 200px;

            border: 3px solid;
            border-radius: 20%;

            background-color: lightgray;
        }
        """)

        self.exNameInput = QLineEdit()
        self.exNameInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 20px;
            max-height: 30px;
            min-width: 200px;
            
            border: 3px solid;
            border-radius: 10%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)

        
        # setCount
        self.setCountLabel = QLabel("Set Count")
        self.setCountLabel.setAlignment(Qt.AlignCenter)
        self.setCountLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 30px;
            max-height: 40px;
            min-width: 200px;

            border: 3px solid;
            border-radius: 20%;

            background-color: lightgray;
        }
        """)

        self.setCountInput = QLineEdit()
        self.setCountInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 20px;
            max-height: 30px;
            min-width: 200px;
            
            border: 3px solid;
            border-radius: 10%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        
        # repCount
        self.repCountLabel = QLabel("Rep Count")
        self.repCountLabel.setAlignment(Qt.AlignCenter)
        self.repCountLabel.setStyleSheet("""
        QLabel {
            font-size: 30px;
            font: bold italic "Times New Roman";
            text-align: center;

            min-height: 30px;
            max-height: 40px;
            min-width: 200px;

            border: 3px solid;
            border-radius: 20%;

            background-color: lightgray;
        }
        """)

        self.repCountInput = QLineEdit()
        self.repCountInput.setStyleSheet("""
        QLineEdit {
            font-size: 30px;
            font: bold italic "Times New Roman";

            min-height: 20px;
            max-height: 30px;
            min-width: 200px;
            
            border: 3px solid;
            border-radius: 10%;
            
            background-color: lightgray;
        }
        QLineEdit:hover {
            background-color: white;
        }
        """)
        
        self.submitButton = QPushButton('Submit Search')
        self.submitButton.clicked.connect(self.goToSubmit)
        self.submitButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 300px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)

        self.backToProfileButton = QPushButton('Back To Profile')
        self.backToProfileButton.clicked.connect(self.goToProfileWindow)
        self.backToProfileButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 300px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)

        self.backToMainMenuButton = QPushButton('Back To Main Menu')
        self.backToMainMenuButton.clicked.connect(self.goToMainMenuWindow)
        self.backToMainMenuButton.setStyleSheet("""
        QPushButton {
            font-size: 20px;
            font-family: "Times New Roman";

            min-height: 30px;
            max-height: 50px;
            min-width: 300px;

            border: 1px solid;
            border-radius: 8%;
         
            background-color: lightgray;
        }
        QPushButton:hover {
            font-size: 25px;
            font: bold italic "Times New Roman";

            background-color: white;
        }
        """)



        self.addToLayout = [(self.title, 0, 0, 1, 5),

                            (self.dateIDLabel, 1, 0, 1, 1), (self.exNameLabel, 1, 1, 1, 1), (self.setCountLabel, 1, 2, 1, 1), (self.repCountLabel, 1, 3, 1, 1),
                            (self.dateIDInput, 2, 0, 1, 1), (self.exNameInput, 2, 1, 1, 1), (self.setCountInput, 2, 2, 1, 1), (self.repCountInput, 2, 3, 1, 1),

                            (self.backToProfileButton, 3, 0, 1, 1), (self.submitButton, 3, 1, 1, 2), (self.backToMainMenuButton, 3, 3, 1, 1)]
        for x in self.addToLayout:
            layout.addWidget(x[0], x[1], x[2], x[3], x[4])
        self.setLayout(layout)
    
    def goToSubmit(self):
        print("Updating")
        pass

    def goToProfileWindow(self):
        self.switchToProfileWindow.emit(UserInfo)
        pass
    def goToMainMenuWindow(self):
        global UserInfo
        self.switchToMenuWindow.emit(UserInfo)