from urllib.response import addinfo
from GUI_Classes import main, os
from dbTablesFunct import addIntoTable, createTable, clearTable, dataBases, modifyTable, selectFromTable, workoutDatabase


if __name__ == "__main__":
	main()

