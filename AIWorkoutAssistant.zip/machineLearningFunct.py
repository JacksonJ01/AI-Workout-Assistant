import numpy as np
import tensorflow as tf
from os import path 
#import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


# This File will be for the machine learning portion of the the program
#filename = "mlTrain.txt"

#if path.isfile(filename):
#    with open(filename, "r") as sampleData:
#        sampleData = list(eval(sampleData.read()))
#    print("File exists and contains the following content:\n Redacted")
#    print(sampleData[0])
#    print("\n", sampleData[-1])
#else:
#    print("File does not exist.")
#    quit()




sampleData = [[[[(3, 18, 0.9997885823249817), (1, 171, 0.037158504128456116), (9, 168, 0.9977356195449829), (7, 165, 0.9450547099113464)], [(4, 45, 0.9997132420539856), (2, 172, 0.9987615346908569), (10, 149, 0.9933092594146729), (8, 164, 0.9706859588623047)]], [[(0, 480, 76, -2.4171729683876038, 0.9987615346908569), (11, 649, 39, -1.4809102714061737, 0.9997885823249817), (12, 351, 114, -1.7111796140670776, 0.9997132420539856), (13, 709, 195, -0.5648471117019653, 0.9602471590042114), (14, 276, 358, -1.5651415586471558, 0.9898871779441833), (15, 744, 360, -0.004724571481347084, 0.9450547099113464), (16, 163, 597, -1.6522636413574219, 0.9706859588623047), (23, 666, 388, 0.044656514190137386, 0.9977356195449829), (24, 515, 421, -0.04529719613492489, 0.9933092594146729), (25, 730, 644, 0.17971204966306686, 0.3943333029747009), (26, 501, 677, -0.0786640215665102, 0.3066755533218384), (27, 725, 802, 1.5576218962669373, 0.0726996436715126), (28, 525, 788, 1.4507143199443817, 0.037158504128456116)]], False], [[[(3, 16, 0.9997608065605164), (1, 174, 0.04834388568997383), (9, 169, 0.9978422522544861), (7, 149, 0.9456498026847839)], [(4, 40, 0.9997193813323975), (2, 172, 0.9988011717796326), (10, 153, 0.9936979413032532), (8, 159, 0.964225709438324)]], [[(0, 493, 51, -2.036376714706421, 0.9988011717796326), (11, 651, 34, -1.1877156794071198, 0.9997608065605164), (12, 363, 106, -1.3220281898975372, 0.9997193813323975), (13, 711, 200, -0.1815679930150509, 0.9583064913749695), (14, 298, 349, -1.3067459464073181, 0.9890149831771851), (15, 750, 362, 0.6040562242269516, 0.9456498026847839), (16, 215, 540, -1.576313853263855, 0.964225709438324), (23, 670, 393, 0.04932517558336258, 0.9978422522544861), (24, 516, 421, -0.04973571561276913, 0.9936979413032532), (25, 730, 646, 0.2758626490831375, 0.42287200689315796), (26, 508, 677, 0.11730855703353882, 0.351214200258255), (27, 708, 713, 1.6579867601394653, 0.08745705336332321), (28, 529, 739, 1.5685919523239136, 0.04834388568997383)]], False]]

input("Press Enter")
exerciseLabels = [
    'abductorLegRaises',
    'barbellSquats',
    'bicepCurls',
    'singleArmBicepCurls',
    'deltoidArmRaises',
    'singleArmDeltoidRaises',
    'frontLatRaises',
    'singleArmFrontLatRaises',
    'gobletSquats',
    'shoulderPress',
    'singleArmShoulderPress'
]

# Define the target range of each exercise
exerciseRanges = {
    'abductorLegRaises': [(0, 135), (0, 150), (130, 155), (170, 180)],
    'barbellSquats': [(30, 90), (75, 150), (0, 135), (0, 135)],
    'bicepCurls': [(0, 30), (0, 90), (160, 180), (160, 180)],
    'singleArmBicepCurls': [(0, 30), (0, 90), (160, 180), (160, 180)],
    'deltoidArmRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'singleArmDeltoidRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'frontLatRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'singleArmFrontLatRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'gobletSquats': [(0, 20), (0, 45), (0, 135), (0, 135)],
    'shoulderPress': [(80, 180), (80, 180), (160, 180), (160, 180)],
    'singleArmShoulderPress': [(80, 180), (80, 180), (160, 180), (160, 180)]
}

def preprocessInput(angles, keyLocations, isRepetition):
    anglesArray = np.array(angles).flatten()
    keyLocationsArray = np.array(keyLocations).flatten()
    isRepetitionArray = np.array([isRepetition])
    inputArray = np.concatenate((anglesArray, keyLocationsArray, isRepetitionArray))
    inputArray = np.expand_dims(inputArray, axis=0)
    return inputArray

## Load the dataset
#sampleData = [ [[], []], [], bool] # example data in new format

# Preprocess the data
X = []
y = []
for sample in sampleData:
    angles = sample[0]
    keyLocations = sample[1]
    isRepetition = sample[2]
    X.append(preprocessInput(angles, keyLocations, isRepetition))
    y.append(isRepetition)
X = np.concatenate(X, axis=0)
y = np.array(y)

# Convert the output data to categorical format
y = tf.keras.utils.to_categorical(y)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(X_train, X_test, y_train, y_test)



# Define the model with different activation functions and optimizers
#shape = (len(sampleData),) + tuple([len(sublist) for sublist in sampleData[:2]]) + (len(sampleData[2]),)
shape = 90
print(shape)
def createModel(activationFn, optimizer):
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation=activationFn, input_shape=shape),
        tf.keras.layers.Dense(64, activation=activationFn),
        tf.keras.layers.Dense(32, activation=activationFn),
        tf.keras.layers.Dense(len(exerciseLabels), activation='softmax')
    ])
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    return model


batchSize = 8
ep = 8

# Define the OneDeviceStrategy
strategy = tf.distribute.OneDeviceStrategy(device="/cpu:0")


# Wrap the model in the strategy's scope
with strategy.scope():
    # Compile the model
    sigmoidOptimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
    sigmoidModel = createModel(tf.keras.activations.sigmoid, sigmoidOptimizer)
    
    # Create a dataset from the input and output samples
    dataSet = tf.data.Dataset.from_tensor_slices((X_train, y_train)).batch(batchSize)
    
    # Train the model
    sigmoidModel.fit(dataSet, epochs=ep, validation_data=(X_test, y_test))
    
    sigmoidModel.save_weights('sigmoidModelWeights.h5')

    input("Here")

# Load the models with different activation functions and optimizers
#sigmoidOptimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
#sigmoidModel = createModel(tf.keras.activations.sigmoid, sigmoidOptimizer)
#sigmoidModel.add_weight('sigmoidModelWeights.h5')
#sigmoidModel.load_weights('sigmoidModelWeights.h5')

#reluOptimizer = tf.keras.optimizers.SGD(learning_rate=0.01, momentum=0.9)
#reluModel = createModel(tf.keras.activations.relu, reluOptimizer)
#reluModel.load_weights('reluModelWeights.h5')

#leakyReluOptimizer = tf.keras.optimizers.RMSprop(learning_rate=0.001)
#leakyReluModel = createModel(tf.keras.layers.LeakyReLU(alpha=0.1), leakyReluOptimizer)
#leakyReluModel.load_weights('leakyReluMmodelWeights.h5')

# Define the function to preprocess the input data

# Define the function to check if angles fall within a range
def isWithinRange(angles, targetRange):
    for angle, tRange in zip(angles, targetRange):
        if angle < tRange[0] or angle > tRange[1]:
            return False
    return True

# Modify the predict_exercise function to use the target ranges
def predictExercise(model, angles, keyLocations, isRepetition):
    inputData = preprocessInput(angles, keyLocations, isRepetition)
    prediction = model.predict(inputData)
    for i, exercisePrediction in enumerate(prediction[0]):
        if exercisePrediction > 0.5:
            exerciseName = exerciseLabels[i]
            if exerciseName in exerciseRanges and isWithinRange(angles, exerciseRanges[exerciseName]):
                return exerciseName
    return "unknown"


#exList = []
#for sampleData in sampleData:
#    exList.append(predictExercise(sigmoidModel, sampleData[0], sampleData[1], sampleData[2]))

#print(exList)



## Load the dataset
#data = [ [[], []], [], bool]