from pickle import FALSE, TRUE
from xmlrpc.client import Boolean
from cv2 import resize, imshow, error, putText, COLOR_BGR2RGB, flip, FILLED, \
    destroyAllWindows, FONT_HERSHEY_PLAIN, cvtColor, circle, waitKey, VideoCapture as VC
import mediapipe as mp
from time import time, sleep

from math import atan2, pi


def readImg(video, pose, drawLM, exName, showInterest=False, showDots=False,
            showLines=False, showRedLines=False, showText=False, known=False, repC=False):
    returned, img = None, None
    try:
        returned, img = video.read()
        img = resize(img, (720, 480))
    except AttributeError:
        pass
    except error:
            pass
    #if not returned:
    #    pass

    img, results = findLandmarks(img, pose)
    img, locationsOfInterest, _ = getLandmarkLocations(img, drawLM, results, showInterest, showDots,
                                                                  showLines, showRedLines, repC)
    leftAngles, rightAngles = [], []
    detected = None
    #repC = False
    try:
        img, leftAngles, rightAngles = calculateAngle(img, locationsOfInterest, showText)
        
        if known is True:
            repC = detectRepetitions(leftAngles, rightAngles, exName)
        else:
            detected, exName = detectExercise(leftAngles, rightAngles, locationsOfInterest)
        #detected, exName = detectExercise(leftAngles, rightAngles, locationsOfInterest)
    except TypeError:
        pass

    #return returned, img, detected, exName, repC, allLocations
    return returned, img, detected, exName, repC  #, allLocations


# _____________________________________________________________________________
def findLandmarks(img, pose):
    """Hello"""

    imgRGB = cvtColor(img, COLOR_BGR2RGB)
    results = pose.process(imgRGB).pose_landmarks
    return img, results


# _____________________________________________________________________________
def getLandmarkLocations(img, drawLM, results, showInterest=False, showDots=False, showLines=False, showRedLines=False, repCompleted=False):
    """

    """

    locationsOfInterests = []
    allLocations = []
    if results:
        if showLines is True:
            connDots = mp.solutions.pose.POSE_CONNECTIONS
            # drawLM.draw_landmarks(img, results, connDots)
            if showRedLines is True and repCompleted is False:
                drawLM.draw_landmarks(img, results, connDots, drawLM.DrawingSpec(color=(0, 0, 255), thickness=2, circle_radius=2)) #,
                                      #drawLM.DrawingSpec(color=(0, 0, 255), thickness=2, circle_radius=2, line_type=drawLM.DrawingSpec.LineType.DOTTED))
            elif showRedLines is True and repCompleted is True:
                drawLM.draw_landmarks(img, results, connDots, drawLM.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2))
            else:
                drawLM.draw_landmarks(img, results, connDots, drawLM.DrawingSpec(color=(0, 0, 0), thickness=2, circle_radius=1))

        for num, info in enumerate(results.landmark):
            h, w, c = img.shape
            xcor, ycor, zcor, vis = int(info.x * w), int(info.y * h), (info.z * c), info.visibility
            allLocations.append((num, xcor, ycor, zcor, vis))

            if num in [0, 11, 12, 13, 14, 15, 16,
                       23, 24, 25, 26, 27, 28]:
                locationsOfInterests.append((num, xcor, ycor, zcor, vis))

                #if showDots is True or showInterest is True and num != 0:
                #    circle(img, (xcor, ycor), 5, (0, 0, 0), FILLED)
                #    #displayText(img, str(num), (xcor, ycor), 2, (255, 0, 0))

    return img, locationsOfInterests, allLocations


# _____________________________________________________________________________
def calculateAngle(img, locationsOfInterest, showText=False):

    leftAngles = []
    rightAngles = []
    for sub, _ in enumerate(locationsOfInterest):
        try:
            x1, y1 = None, None
            x2, y2 = None, None
            x3, y3 = None, None

            if sub in [1, 2, 7, 8]:
                _, x1, y1, _, _ = locationsOfInterest[sub]
                _, x2, y2, _, _ = locationsOfInterest[sub + 2]
                _, x3, y3, _, _ = locationsOfInterest[sub + 4]

            elif sub in [3, 4]:
                _, x1, y1, _, _ = locationsOfInterest[sub]
                _, x2, y2, _, _ = locationsOfInterest[sub - 2]
                _, x3, y3, _, _ = locationsOfInterest[sub + 4]

            elif sub in [9, 10]:
                _, x1, y1, _, _ = locationsOfInterest[sub]
                _, x2, y2, _, _ = locationsOfInterest[sub - 2]
                _, x3, y3, _, _ = locationsOfInterest[sub - 8]

            #
            angle = abs(atan2(y3 - y2, x3 - x2) - atan2(y1 - y2, x1 - x2))
            angle = int(angle * 180 / pi)

            if angle > 180:
                # The joints will never bend the opposite way,
                # so this prevents the program from giving you an angle greater than 180
                angle = 180 - (angle - 180)

            if sub % 2 == 0:
                #formatting the data to be saved in a list as a tuple element
                # The node point number, angle, visibilityw
                rightAngles.append((sub, angle, locationsOfInterest[sub - 2][4]))
            else:
                leftAngles.append((sub, angle, locationsOfInterest[sub - 2][4]))

            # Display the angles on screen
            if showText is True:
                displayText(img, str(angle), (x2, y2), 1, (255, 0, 0))
                pass

        except TypeError:
            pass

        #Elbow angles     | 1, 2
        #Shoulder angles  | 3, 4
        #Knee angles      | 7, 8
        #Hip angles#      | 9, 10
    
    try:
        leftAngles[0], leftAngles[1] = leftAngles[1], leftAngles[0]
        leftAngles[2], leftAngles[3] = leftAngles[3], leftAngles[2]

        rightAngles[0], rightAngles[1] = rightAngles[1], rightAngles[0]
        rightAngles[2], rightAngles[3] = rightAngles[3], rightAngles[2]
        
        # Reformatted
        #Shoulder angles  | 3, 4
        #Elbow angles     | 1, 2
        #Hip angles#      | 9, 10
        #Knee angles      | 7, 8
        #print(leftAngles, rightAngles)

        return img, leftAngles, rightAngles

    except IndexError:
        pass


# _____________________________________________________________________________
def checkVisibility(leftVisibility: list, rightVisibility: list):
    """"""

    leftShoulder = leftVisibility[0][2]
    leftElbow = leftVisibility[1][2]
    # leftWrist = leftVisibility
    leftHip = leftVisibility[2][2]
    leftKnee = leftVisibility[3][2]
    # leftAnkle = leftVisibility
    leftVisibility = [leftShoulder, leftElbow, leftHip, leftKnee]

    rightShoulder = rightVisibility[0][2]
    rightElbow = rightVisibility[1][2]
    # rightWrist = rightVisibility
    rightHip = rightVisibility[2][2]
    rightKnee = rightVisibility[3][2]
    # rightAnkle = rightVisibility
    rightVisibility = [rightShoulder, rightElbow, rightHip, rightKnee]

    visibility = [[], []]
    for left in leftVisibility:
        if left > .85:
            visibility[0].append(True)
        else:
            visibility[0].append(False)

    for right in rightVisibility:
        if right > .85:
            visibility[1].append(True)
        else:
            visibility[1].append(False)

    # print(visibility)
    return visibility
    
    
def trackLocation(specifcPositioning, loc: list, angles):
    """
    Loc:
    # 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12,
    # 0, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28

    Nose 0, 
    0
    leftShoulder 11, leftElbow 13, leftWrist 15,
    1, 3, 5
    rightShoulder 12, rightElbow 14, rightWrist 16,
    2, 4, 6
    leftHip 23, leftKnee 25, leftAnkle 27,
    7, 9, 11
    rightHip 24, rightKnee 26, rightAnkle 28
    8, 10, 12

    (num, xcor, ycor, zcor, vis)

    """
    checking = False
        
    if specifcPositioning == 0:
        legOut = [True, True]
        for pos in loc:
            if pos[0] != 27 or pos[0] != 28:
                leftAnkleX = loc[11][1]
                rightAnkleX = loc[12][1]
                # If the LEFT or RIGHT leg is not the furthest out, then the loop will return False
                if pos[0] % 2 != 0 and pos[0] != 27:
                    if pos[1] < leftAnkleX:
                        pass
                    else:
                        legOut[0] = False
                elif pos[0] % 2 == 0 and pos[0] != 28:
                    if rightAnkleX < pos[1]:
                        pass
                    else:
                        legOut[1] = False

        # If the loop makes it to this point without leaving, this exercise is returned as True
        # print(legOut)
        if True in legOut:
            #print("Left Ankle Is Out") if legOut[0] is True else print("Right Ankle Is Out") 
            checking = True

    elif specifcPositioning == 1:
        noseHeight = int(loc[0][2])
        avgShoulderHeight = (int(loc[1][2]) + int(loc[2][2])) // 2
        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2

        if noseHeight < avgShoulderHeight < avgElbowHeight and \
            noseHeight < avgWristHeight < avgElbowHeight:
            checking = True

    elif specifcPositioning == 2:
        noseHeight = int(loc[0][2])
        LeftWristHeight = int(loc[5][2])
        RightWristHeight = int(loc[6][2])
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2

        if noseHeight < LeftWristHeight < avgElbowHeight and \
            noseHeight < RightWristHeight < avgElbowHeight:
            checking = True

        checking = True
    elif specifcPositioning == 3:
        noseHeight = int(loc[0][2])
        avgShoulderHeight = (int(loc[1][2]) + int(loc[2][2])) // 2
        leftWristHeight = int(loc[5][2])
        rightWristHeight = int(loc[6][2])
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2

        if ((avgShoulderHeight < avgElbowHeight < leftWristHeight) and (noseHeight < rightWristHeight < avgElbowHeight)) \
            or ((avgShoulderHeight < avgElbowHeight < rightWristHeight) and (noseHeight < leftWristHeight < avgElbowHeight)):
            checking = True

    elif specifcPositioning == 4:
        noseHeight = int(loc[0][2])

        leftWristX = int(loc[5][1])
        rightWristX = int(loc[6][1])
        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2

        leftShoulderX = int(loc[1][1])
        rightShoulderX = int(loc[2][1])
        avgHipShoulderMidHeight = ((int(loc[1][2]) + int(loc[2][2])) + (int(loc[7][2]) + int(loc[8][2]))) // 4

        leftElbowX = int(loc[3][1])
        rightElbowX = int(loc[4][1])
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2
        
        if rightWristX < rightElbowX < rightShoulderX and \
            leftShoulderX < leftElbowX < leftWristX and \
            noseHeight < avgWristHeight < avgHipShoulderMidHeight and \
            noseHeight < avgElbowHeight < avgHipShoulderMidHeight:
            checking = True

    elif specifcPositioning == 5:
        noseHeight = int(loc[0][2])

        leftWristX = int(loc[5][1])
        rightWristX = int(loc[6][1])
        leftWristHeight = int(loc[5][2])
        rightWristHeight = int(loc[6][2])

        leftShoulderX = int(loc[1][1])
        rightShoulderX = int(loc[2][1])
        avgHipShoulderMidHeight = ((int(loc[1][2]) + int(loc[2][2])) + (int(loc[7][2]) + int(loc[8][2]))) // 4

        leftElbowX = int(loc[3][1])
        rightElbowX = int(loc[4][1])
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2
        
        if (rightWristX < rightElbowX < rightShoulderX or \
            leftShoulderX < leftElbowX < leftWristX) and \
            (noseHeight < leftWristHeight < avgHipShoulderMidHeight or \
            noseHeight < rightWristHeight < avgHipShoulderMidHeight):
            checking = True

    elif specifcPositioning == 6:
        noseHeight = int(loc[0][2])

        leftWristX = int(loc[5][2])
        rightWristX = int(loc[6][2])
        avgWristZ = int(int(loc[5][3]) + int(loc[6][3])) // 2

        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2
        leftElbowX = int(loc[3][1])
        rightElbowX = int(loc[4][1])
        avgElbowZ = int(int(loc[3][3]) + int(loc[4][3])) // 2
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2

        leftShoulderX = int(loc[1][1])
        rightShoulderX = int(loc[2][1])
        avgShoulderZ = int(int(loc[1][3]) + int(loc[2][3])) // 2
        avgHipShoulderMidHeight = ((int(loc[1][2]) + int(loc[2][2])) + (int(loc[7][2]) + int(loc[8][2]))) // 4

        
        if noseHeight < avgWristHeight < avgHipShoulderMidHeight and \
            noseHeight < avgElbowHeight < avgHipShoulderMidHeight:
            if avgShoulderZ < avgElbowZ < avgWristZ:
                checking = True

    elif specifcPositioning == 7:
        noseHeight = int(loc[0][2])

        leftWristX = int(loc[5][2])
        rightWristX = int(loc[6][2])
        avgWristZ = int(int(loc[5][3]) + int(loc[6][3])) // 2

        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2
        leftElbowX = int(loc[3][1])
        rightElbowX = int(loc[4][1])
        avgElbowZ = int(int(loc[3][3]) + int(loc[4][3])) // 2
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2

        leftShoulderX = int(loc[1][1])
        rightShoulderX = int(loc[2][1])
        avgShoulderZ = int(int(loc[1][3]) + int(loc[2][3])) // 2
        avgHipShoulderMidHeight = ((int(loc[1][2]) + int(loc[2][2])) + (int(loc[7][2]) + int(loc[8][2]))) // 4
        
        if noseHeight < avgWristHeight < avgHipShoulderMidHeight or \
            noseHeight < avgElbowHeight < avgHipShoulderMidHeight:
            checking = True

    elif specifcPositioning == 8:
        noseHeight = int(loc[0][2])

        leftWristX = int(loc[5][1])
        rightWristX = int(loc[6][1])
        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2

        leftShoulderX = int(loc[1][1])
        rightShoulderX = int(loc[2][1])
        #avgHipShoulderMidHeight = ((int(loc[1][2]) + int(loc[2][2])) + (int(loc[7][2]) + int(loc[8][2]))) // 4

        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2
        
        if rightShoulderX < rightWristX < leftWristX < leftShoulderX:
            if noseHeight < avgWristHeight < avgElbowHeight:
               checking = True

    elif specifcPositioning == 9:
        noseHeight = int(loc[0][2])
        avgWristHeight = (int(loc[5][2]) + int(loc[6][2])) // 2
        avgElbowHeight = (int(loc[3][2]) + int(loc[4][2])) // 2
        
        leftAngle, rightAngle = angles[0][1], angles[1][1]

        #print(angles, leftAngle, rightAngle)
        #print("here",
                  #noseHeight,
                  #avgWristHeight, 
                  #avgElbowHeight)
        if avgWristHeight < noseHeight < avgElbowHeight:
            #print("here")
            if leftAngle[1] < 135 and rightAngle[1] < 135:
                checking = True

    elif specifcPositioning == 10:
        noseHeight = int(loc[0][2])
        leftWristHeight = int(loc[5][2]) 
        rightWristHeight = int(loc[6][2])
        leftElbowHeight = int(loc[3][2]) 
        rightElbowHeight = int(loc[4][2])

        leftAngle, rightAngle = angles[0][1], angles[1][1]
        #print(angles, leftAngle, rightAngle)
        #print("here",
        #          noseHeight,
        #          leftWristHeight, 
        #          rightWristHeight,
        #          leftElbowHeight,
        #          rightElbowHeight)

        if leftWristHeight < noseHeight < leftElbowHeight or \
            rightWristHeight < noseHeight < rightElbowHeight:
            #print("here")



            if leftAngle[1] < 135 or rightAngle[1] < 135:
                checking = True

    #print(checking)
    return checking


# _____________________________________________________________________________
class Exercise:
    """
    This is the Exercise Class:
    The Attributes in the 8 Locations of interest are represented as tuples here
    (minimum expected angle, maximum EA, target EA)

    Bicep Curls and Single Arm Bicep Curls both use the same base angles, 
     so that distinction is made with the Boolean mirrored variable
    
    The Specific Positioning is how I will check these exercises in the trackLocation function 
     """

    def __init__(self, name,
                 pit, elbow, hip, knee,
                 mirrored=True,
                 specificPositioning: int=None,
                 skipFull: list=None):
        """
        Each exercise will have its own set of angles, and other attributes
        """
        self.name = name
        self.angles = [pit, elbow, hip, knee]
        self.mirrored = mirrored
        self.specific = specificPositioning
        self.sFull = skipFull

    def exerciseAngles(self):
        return self.angles


abductorLegRaises = Exercise("Abductor Leg Raises",
                             (0, 120), (0, 180), (110, 155), (170, 180),
                             False, 0)

barbellSquats = Exercise("Barbell Squats",
                         (30, 90), (75, 150), (0, 135), (0, 135),
                         True, 1, [0, 1])

bicepCurls = Exercise("Bicep Curls",
                      (0, 30), (0, 90), (160, 180), (160, 180),
                      True, 2)
singleArmBicepCurls = Exercise("Single Arm Bicep Curls",
                               (0, 30), (0, 90), (160, 180), (160, 180),
                               False, 3)

deltoidArmRaises = Exercise("Deltoid Arm Raises",
                            (85, 135), (160, 180), (160, 180), (160, 180),
                            True, 4)
singleArmDeltoidRaises = Exercise("Single Arm Deltoid Raises",
                                  (85, 135), (160, 180), (160, 180), (160, 180),
                                  False, 5)

frontLatRaises = Exercise("Front Lat Raises",
                          (75, 135), (160, 180), (160, 180), (160, 180),
                          True, 6)
singleArmFrontLatRaises = Exercise("Single Arm Front Lat Raises",
                                   (75, 135), (160, 180), (160, 180), (160, 180),
                                   False, 7)

gobletSquats = Exercise("Goblet Squats",
                        (0, 45), (0, 60), (0, 135), (0, 135),
                        True, 8)

shoulderPress = Exercise("Shoulder Press",
                         (80, 180), (80, 180), (160, 180), (160, 180),
                         True, 9)
singleArmShoulderPress = Exercise("Single Arm Shoulder Press",
                                  (80, 180), (80, 180), (160, 180), (160, 180),
                                  False, 10)


exercises = [abductorLegRaises,
             #barbellSquats,
             bicepCurls,      
             singleArmBicepCurls,
             deltoidArmRaises,
             singleArmDeltoidRaises,
             #frontLatRaises,          
             #singleArmFrontLatRaises,
             gobletSquats,
             shoulderPress,
             singleArmShoulderPress]


# _____________________________________________________________________________
def detectExercise(leftAngles, rightAngles, loc):
    """
    Exercises listed below have 2 lists. These lists correlate to the major and minor angles list;
    When the computer checks for the exercises, it will loop through the list and append that to another loop#

    The first [] takes you to either the:
    exerciseLeftAngles list: [0] or
    exerciseRightAngles list [1]

    The second [] takes you to the specific angle range for each exercise:
    Shoulder Angle Range: [0]
    Elbow Angle Range: [1]
    Knee Angle Range: [2]
    Hip Angle Range: [3]

    The third [] takes you to the:
    Minimum range: [0]
    Maximum range: [1]  
    """
 
    pE = []
    mirrored = {}
    angles = leftAngles, rightAngles
    for exercise in exercises:
        #print('\n\n', exercise.name)
        try:
            mirrored[exercise.name] = [True, True]
            for sub in range(2):
                # The name of the exercise is stored in the mirrored dictionary
                #  As the loop iterates twice
                #   If the currentAngle is between that of the exercise being checked, 
                #    the left or right print False will stay True
                #   That tells me if the exercise being done is, well, mirrored 
                for point in range(4):
                    # point loops though the shoulder, elbow, hip, and knee angles
                    if exercise.angles[point][0] <= angles[sub][point][1] <= exercise.angles[point][1]:
                        #print('\nTrue', sub, point, 
                        #        exercise.angles[point][0], "<=", angles[sub][point][1], "<=", exercise.angles[point][1])
                        pass
                    else:
                        #print('\nFalse', sub, point, 
                        #        exercise.angles[point][0], "<=", angles[sub][point][1], "<=", exercise.angles[point][1])
                        mirrored[exercise.name][sub] = False
                        
            if True in mirrored[exercise.name]:
                pE.append(exercise)
                #print(exercise.name, mirrored[exercise.name])

        except IndexError:
            pass

    #print('\n1', [x.name for x in pE],
    #      '\n', angles)
    
    _pE = [x for x in pE]
    pE = []
    for sub, exer in enumerate(_pE):
        a, b = mirrored[exer.name]
        if (a is True and b is True) and exer.mirrored is True:
            pE.append(exer)
        elif (a is False or b is False) and exer.mirrored is False: 
            pE.append(exer)
        else:
            pass

  
    _pE = []
    #print('\nLoc:', loc, '\n')
    for exer in pE:
        if trackLocation(exer.specific, loc, angles) is True:
            #print(exer.name, 'has potential')
            _pE.append(exer)
        else:
            pass

    try:
        #print(_pE)
        #print("\nExercise Check")
        #print('\n4', [x.name for x in _pE])
        #input("Press Enter For Next Check")
        # If there is more than one exercise in the list, then it will pass and check against a new list
        if len(_pE) == 1:
            #print(_pE[0].name)
            return True, _pE
        elif 1 < len(_pE):
            #print(x.name for x in _pE)
            return False, _pE
    except IndexError:
        pass

    return False, []


# _____________________________________________________________________________
def detectRepetitions(leftAngles, rightAngles, exName: Exercise=None):
    # print(f"\nDetecting Reps For: {exName.name}\n")
    #input("Wait Here1")
    try:
        currentAngle = leftAngles, rightAngles
        reps = [True, True]

        for sub in range(2):
            for point in range(4):
                # point loops though the shoulder, elbow, hip, and knee angles
                #print(exName.angles[point][0], '<=', currentAngle[sub][point][1], '<=', exName.angles[point][1])
                if exName.angles[point][0] <= currentAngle[sub][point][1] <= exName.angles[point][1]:
                    pass
                else:
                    reps[sub] = False
                

        if reps[0] is True and reps[1] is True and exName.mirrored is True:
            return True
        elif reps[0] is True or reps[1] is True and exName.mirrored is False:
            return True
        else:
           return False

    except IndexError:
        return False

# _____________________________________________________________________________
def displayText(img, txt, location: tuple, size=1, color=(255, 0, 0), thickness=3):
    putText(img, txt, location, FONT_HERSHEY_PLAIN, size, color, thickness)
    return img


# _____________________________________________________________________________
def fps(img, pTime):
    try:
        cTime = time()
        frames = 1 / (cTime - pTime)
        pTime = cTime

        putText(img, str(int(frames)), (30, 30), FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 3)
    except ZeroDivisionError:
        pass
    return pTime


# _____________________________________________________________________________
def terminateWindows(video):
    video.release()
    destroyAllWindows()


def padding(pad):
    padless = len(pad)
    if padless < 19:
        pad += " " * (19 - padless)
    return pad


#def findDur(imgObj):
#    imgObj.seek(0)
#    total = 0
#    while True:
#        try:
#            # print(total)
#            frame_duration = imgObj.info['duration']  # returns current frame duration in milli sec.
#            total += frame_duration
#            # now move to the next frame of the gif
#            imgObj.seek(imgObj.tell() + 1)  # image.tell() = current frame

#        except EOFError:
#            return total / 1000

#
# gif = Image.open("C:\\Users\\Big Boi J\\Downloads\\test1.gif")
# length = findDur(gif)
# print(length / 1000)



# _____________________________________________________________________________
# _____________________________________________________________________________
def machineLeaningInput(exName, angles: list, keyLocations: list, repCompleted: bool):
    


    return



"""
import numpy as np
import tensorflow as tf

exerciseLabels = [
    'abductorLegRaises',
    'barbellSquats',
    'bicepCurls',
    'singleArmBicepCurls',
    'deltoidArmRaises',
    'singleArmDeltoidRaises',
    'frontLatRaises',
    'singleArmFrontLatRaises',
    'gobletSquats',
    'shoulderPress',
    'singleArmShoulderPress'
]

# Define the target range of each exercise
exerciseRanges = {
    'abductorLegRaises': [(0, 135), (0, 150), (130, 155), (170, 180)],
    'barbellSquats': [(30, 90), (75, 150), (0, 135), (0, 135)],
    'bicepCurls': [(0, 30), (0, 90), (160, 180), (160, 180)],
    'singleArmBicepCurls': [(0, 30), (0, 90), (160, 180), (160, 180)],
    'deltoidArmRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'singleArmDeltoidRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'frontLatRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'singleArmFrontLatRaises': [(75, 135), (160, 180), (160, 180), (160, 180)],
    'gobletSquats': [(0, 20), (0, 45), (0, 135), (0, 135)],
    'shoulderPress': [(80, 180), (80, 180), (160, 180), (160, 180)],
    'singleArmShoulderPress': [(80, 180), (80, 180), (160, 180), (160, 180)]
}

# Define the model with different activation functions and optimizers
def createModel(activationFn, optimizer):
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation=activationFn, input_shape=(34,)),
        tf.keras.layers.Dense(64, activation=activationFn),
        tf.keras.layers.Dense(32, activation=activationFn),
        tf.keras.layers.Dense(len(exerciseLabels), activation='softmax')
    ])
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Load the models with different activation functions and optimizers
sigmoidOptimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
sigmoidModel = createModel(tf.keras.activations.sigmoid, sigmoidOptimizer)
sigmoidModel.load_weights('sigmoidModelWeights.h5')

reluOptimizer = tf.keras.optimizers.SGD(learning_rate=0.01, momentum=0.9)
reluModel = createModel(tf.keras.activations.relu, reluOptimizer)
reluModel.load_weights('reluModelWeights.h5')

leakyReluOptimizer = tf.keras.optimizers.RMSprop(learning_rate=0.001)
leakyReluModel = createModel(tf.keras.layers.LeakyReLU(alpha=0.1), leakyReluOptimizer)
leakyReluModel.load_weights('leakyReluMmodelWeights.h5')

# Define the function to preprocess the input data
def preprocessInput(angles, keyLocations, isRepetition):
    anglesArray = np.array(angles).flatten()
    keyLocationArray = np.array(keyLocations).flatten()
    isRepetitionArray = np.array([isRepetition])
    inputArray = np.concatenate((anglesArray, keyLocationsArray, isRepetitionArray))
    inputArray = np.expand_dims(inputArray, axis=0)
    return inputArray

# Define the function to check if angles fall within a range
def isWithinRange(angles, targetRange):
    for angle, tRange in zip(angles, targetRange):
        if angle < tRange[0] or angle > tRange[1]:
            return False
    return True

# Modify the predict_exercise function to use the target ranges
def predictExercise(model, angles, keyLocations, isRepetition):
    inputData = preprocessInput(angles, keyLocations, isRepetition)
    prediction = model.predict(inputData)
    for i, exercisePrediction in enumerate(prediction[0]):
        if exercisePrediction > 0.5:
            exerciseName = exerciseLabels[i]
            if exerciseName in exerciseRanges and isWithinRange(angles, exerciseRanges[exerciseName]):
                return exercise_name
    return "unknown"


exList = []
for data in sampleData:
    exList.append(predictExercise(sigmoidModel, data[0], data[1], data[2]))

print(exList)



import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load the dataset
data = [ [[], []], [], bool] # example data in new format

# Preprocess the data
X = []
y = []
for sample in data:
    angles = sample[0]
    keyLocations = sample[1]
    isRepetition = sample[2]
    X.append(preprocessInput(angles, keyLocations, isRepetition))
    y.append(isRepetition)
X = np.concatenate(X, axis=0)
y = np.array(y)

# Convert the output data to categorical format
y = tf.keras.utils.to_categorical(y)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the model with different activation functions and optimizers
def createModel(activationFn, optimizer):
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation=activationFn, input_shape=(34,)),
        tf.keras.layers.Dense(64, activation=activationFn),
        tf.keras.layers.Dense(32, activation=activationFn),
        tf.keras.layers.Dense(len(labelEncoder.classes_), activation='softmax')
    ])
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Train the model and evaluate on the test set
activations = ['relu', 'sigmoid', 'tanh']
optimizers = ['adam', 'sgd', 'rmsprop']
for activation in activations:
    for optimizer in optimizers:
        print(f'Training model with activation={activation} and optimizer={optimizer}...')
        model = createModel(activation, optimizer)
        model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=0)
        loss, acc = model.evaluate(X_test, y_test, verbose=0)
        print(f'Test set accuracy: {acc}')
"""