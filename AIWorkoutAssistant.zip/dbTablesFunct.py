from pickle import FALSE
from dbTables import dataBases
from PyQt5.QtSql import QSqlDatabase, QSqlTableModel, QSqlRelationalTableModel, QSqlQuery
from PyQt5.QtCore import QDate

# creates the database###############################################################################3
def workoutDatabase():
    #connect = None
    #try:
    conn = QSqlDatabase.addDatabase("QSQLITE")
    conn.setDatabaseName("workoutDB.sqlite")
    print('connection successful'.upper())
    if not conn.open():
        print("Database Error: %s" % conn.lastError().databaseText())
    #except Error as oops:
    #    print('there has been an error:', oops)
    
    try:
        if conn.isOpen():  
            return conn
    except:
        print("Error")


def addIntoTable(conn, table: str, data: dict):
    columnName = [col for col in data]
    valueName = []

    for val in data:
        valueName.append(data[val])

    colFormat = ""
    for col in columnName:
        colFormat += f"{col}, "
    valFormat = ""
    for val in valueName:
        valFormat += f"'{val}', "
    colFormat, valFormat = colFormat[:-2], valFormat[:-2]
 
    addToTable = f"""
    INSERT INTO
        {table} 
        ({colFormat})
    VALUES
        ({valFormat})"""

    try:
        #Conn = workoutDatabase()
        if conn.isOpen():
            return QSqlQuery().exec(addToTable)
    except: 
        print("Could Not")
    finally:
        print(addToTable)


def clearTable(conn, clearPersonTable=False,
               clearExerciseTable=False, clearWorkoutDataTable=False,
               clearAll=False, clearAllPassword=None):
    tablesToClear = [
        clearPersonTable, 
        clearExerciseTable,
        clearWorkoutDataTable
        ]
         

    if True in tablesToClear or (clearAll is True and clearAllPassword == "Clear"):
        for database, clearTable in enumerate(tablesToClear):
            if clearTable is True or (clearAll is True and clearAllPassword == "Clear"):
                dropTable = f"""
                Drop Table if exists
                    {dataBases[database][1]}
                """
                try: 
                    if conn.isOpen():
                        QSqlQuery().exec(dropTable)
                except: 
                    print("Could Not")


def createTable(conn, table: str):
    try: 
        if conn.isOpen():
            QSqlQuery().exec(table)
    except:
        print("Could Not")
    print(table)


def deleteFromTable(table: str, fromWhere: dict):
    global dbConnection

    fromFormat = ""
    for col in fromWhere:
        fromFormat += f"{col} = '{fromWhere[col]}' AND "
    fromFormat = fromFormat[:-5]
    
    delFromTable = f"""
    DELETE FROM 
        {table}
    WHERE
        {fromFormat}
    """

    #try: 
    #    if dbConnection.isOpen():
    #        QSqlQuery().exec(delFromTable)
    #except: 
    #    print("Could Not")
    
    print(delFromTable)
        

def modifyTable(table: str, toSet: dict, fromWhere: dict):
    global dbConnection

    setFormat = ""
    for setCol in toSet:
        setFormat += f"{setCol} = '{toSet[setCol]}', "
    setFormat = setFormat[:-2]

    fromFormat = ""
    for col in fromWhere:
        fromFormat += f"{col} = '{fromWhere[col]}' AND "
    fromFormat = fromFormat[:-5]

    modTable = f"""
    UPDATE
        {table}
    SET
        {setFormat}
    WHERE
        {fromFormat}
    """

    #try: 
    #    if dbConnection.isOpen():
    #        QSqlQuery().exec(modTable)
    #except: 
    #    print("Could Not")
    
    print(modTable)



def selectFromTable(conn, table: str, columns=None, colNum=None, fromWhere=None):

    selFromTable: str = ""
    
    if columns is not None and fromWhere is not None:
        colFormat = ""
        for col in columns:
            colFormat += f"{col}, "
        colFormat = colFormat[:-2]

        fromFormat = ""
        for col in fromWhere:
            fromFormat += f"{col} = '{fromWhere[col]}' AND "
        fromFormat = fromFormat[:-5]

        selFromTable = f"""
            SELECT
                {colFormat}
            FROM
                {table}
            WHERE  
                {fromFormat}
        """

    elif fromWhere is not None and colNum is not None:
        columns = ["val"] * colNum

        fromFormat = ""
        for col in fromWhere:
            fromFormat += f"{col} = '{fromWhere[col]}' AND "
        fromFormat = fromFormat[:-5]

        selFromTable = f"""
            SELECT
                *
            FROM
                {table}
            WHERE 
                {fromFormat}
        """

    elif columns is not None:
        colFormat = ""
        for col in columns:
            colFormat += f"{col}, "
        colFormat = colFormat[:-2]

        selFromTable = f"""
            SELECT
                {colFormat}
            FROM
                {table}
        """
    else:
        columns = ["val"] * colNum

        selFromTable = f"""
            SELECT
                *
            FROM
                {table}
        """

    try: 
        if conn.isOpen():
            #print(conn, table, columns, fromWhere)
            #print(selFromTable)
            query = QSqlQuery(selFromTable)
            dataB = []
            while query.next():
                #print("Here2", query.value(0))
                data = []
                for val in range(0, len(columns)):
                    data.append(query.value(val))
                dataB.append(data)

            dataB_ = dataB[0][0]
            
            return dataB
    except IndexError:
        return [[False]] 


def checkReq(userInput:list, req: list = None):
    if req is None:
        num = 0
        for currentColInput in userInput:
            if currentColInput.text() != "":
                num += 1
            else:
                return False, num
    else:
        for num in req:
            if userInput[num].text() != "":
                pass
            else:
                return False, num


def checkDataType(dataType: int, data):
    try:
        if dataType == 1:
            data = int(data)
        elif 2 <= dataType <= 3:
            pass

        return True

    except ValueError:
        return data
    except TypeError:
        return data


# TEXT: 0
# INTEGER: 1
# DATE: 2
# TIME: 3
PersonData = {
    "userName": 0,
    "password": 0,
    "firstName": 0,
    "lastName": 0,
    "apiKey": 0
}

ExerciseData = {
    "exName": 0,
    "muscleGroups": 0

 }

WorkoutData = {
    "workoutEntryNum": 1,
    "userName": 0,
    "dateID": 2,
    "exName": 0,
    "setCount": 1,
    "repCount": 1
 }

#"""

conn = workoutDatabase()

#TESTING

print(conn.tables())
#clearTable(conn, clearPersonTable=True)
#print(conn.tables())

# MOCK USER INFO
#manualCreation0 = {
#    "userName": "JJ01",
#    "password": "fitness",
#    "firstName": "Jared",
#    "lastName": "Jackson",
#    }

#manualCreation1 = {
#    "userName": "BB0",
#    "password": "abc",
#    "firstName": "Sharhea",
#    "lastName": "Wright-Havens",
#    }

#manualCreation2 = {
#    "userName": "Fit",
#    "password": "ness",
#    "firstName": "J",
#    "lastName": "J",
#    }

#createTable(conn, dataBases[0][0])
#print(conn.tables())

#addIntoTable(conn, dataBases[0][1], manualCreation0)
#addIntoTable(conn, dataBases[0][1], manualCreation1)
#addIntoTable(conn, dataBases[0][1], manualCreation2)


#columns = ["userName", "password", "firstName", "lastName"]
#fromWhere = {
#    "userName": manualCreation2["userName"]
#    }
#query: list = selectFromTable(conn, dataBases[0][1], colNum=5)
#for x in query:
#    print("Peep Info")


# EXERCISE INFO

exercise0 = {
    "exName": "Abductor Leg Raises", 
    "muscleGroups": "Abductors | Obliques",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/abductorLegRaiseFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/abductorLegRaiseTrue.png",
    "exerciseDesc": "Abductor Leg Raises engage muscles in your outer hips and thighs. To perform the exercise, stand with your feet shoulder-width apart and place a resistance band around your ankles. "
    "Lift one leg out to the side as high as you can while keeping the other foot firmly on the ground, then slowly lower it back down. Repeat for the desired number of reps, then switch sides. "
    "Keep your core engaged and avoid leaning to one side. You can also perform the exercise without a resistance band or hold onto a stable object, such as a wall or chair, for balance support. "
    "This exercise can help improve hip mobility and stability."
    }

#exercise1 = {
#    "exName": "Barbell Squats", 
#    "muscleGroups": "Quads | Glutes | Lower Back",
#    "repFalsePic": "./AIWorkoutAssistant/helpPictures/",
#    "repTruePic": "./AIWorkoutAssistant/helpPictures/",
#    "exerciseDesc": "Barbell squats are a compound exercise that target the lower body, including the quadriceps, hamstrings, glutes, and calves, as well as the core muscles. "
#    "To perform the exercise, stand with your feet shoulder-width apart and position a barbell on your upper back, resting it on your traps. Keeping your chest up and your core engaged, "
#    "lower your body by bending your knees and pushing your hips back, as if sitting in a chair. Keep your knees in line with your toes and your weight on your heels. "
#    "Stop when your thighs are parallel to the ground, then push through your heels to lift your body back up to the starting position. Avoid arching your back or rounding your shoulders. "
#    "Start with a lighter weight and gradually increase as you become more comfortable with the exercise."
#    }

exercise2 = {
    "exName": "Bicep Curls", 
    "muscleGroups": "Biceps",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/bicepCurlFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/bicepCurlTrue.png",
    "exerciseDesc": "Bicep curls are performed by holding a dumbbell or barbell in front of your thighs with an underhand grip, palms facing up. "
    "Keeping your elbows close to your body, lift the weight towards your shoulders by bending your elbows. "
    "Slowly lower the weight back down to the starting position. This exercise targets the biceps brachii muscle, located in the front of your upper arm. "
    "It is important to avoid swinging or using momentum to lift the weight, as this can decrease the effectiveness of the exercise and increase the risk of injury. "
    "Focus on maintaining control and a slow, steady pace throughout the movement."
    }


exercise3 = {
    "exName": "Single Arm Bicep Curls", 
    "muscleGroups": "Biceps",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/bicepCurlFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/singleBicepCurlTrue.png",
    "exerciseDesc": "Single Arm Bicep Curls are performed similar to regular bicep curls, but with one arm at a time. Hold a dumbbell or resistance band in one hand with your palm facing up. " 
    "Keeping your elbow close to your body, lift the weight towards your shoulder by bending your elbow. Lower the weight back down to the starting position and repeat on the other arm. " 
    "To prevent leaning or twisting, stand with your feet shoulder-width apart and engage your core throughout the exercise, "
    "maintaining a neutral spine to avoid excessive swinging or momentum, which can put undue stress on your lower back."
    }


exercise4 = {
    "exName": "Deltoid Arm Raises", 
    "muscleGroups": "Deltoids | Traps",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/deltiodArmRaiseFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/deltoidArmRaiseTrue.png",
    "exerciseDesc": "Deltoid arm raises are an isolation exercise that target the shoulder muscles, particularly the middle portion of the deltoids. To perform the exercise, "
    "stand with your feet shoulder-width apart and hold a dumbbell in each hand by your sides. With your palms facing inward, lift your arms out to the sides until they are parallel to the ground, "
    "then slowly lower them back down. Avoid swinging or using momentum, and focus on squeezing your shoulder muscles at the top of the movement. You can also perform the exercise one arm at a time or with a resistance band. "
    "Start with a lighter weight and gradually increase as you become more comfortable with the exercise."
    }


exercise5 = {
    "exName": "Single Arm Deltoid Raises", 
    "muscleGroups": "Deltoids | Traps",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/deltiodArmRaiseFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/singleArmDeltoidTrue.png",
    "exerciseDesc": "Single arm deltoid raises target one shoulder at a time. To perform the exercise, "
    "stand with your feet shoulder-width apart and hold a dumbbell in one hand by your side. With your palm facing inward, lift your arm out to the side until it is parallel to the ground, "
    "then slowly lower it back down. Keep your torso stable and avoid twisting or leaning to one side. Focus on squeezing your shoulder muscles at the top of the movement and maintain control throughout the exercise. "
    "You can perform the same number of reps on each arm or alternate arms between sets. Using a lighter weight can help you maintain proper form and prevent injury."
    }


#exercise6 = {
#    "exName": "Front Lat Raises",
#    "muscleGroups": "Deltoids | Traps | Lats",
#    "repFalsePic": "./AIWorkoutAssistant/helpPictures/.png",
#    "repTruePic": "./AIWorkoutAssistant/helpPictures/.png",
#    "exerciseDesc": "Front lat raises target the front portion of the shoulder muscles. To perform this exercise, stand with your feet shoulder-width apart and hold a dumbbell in each hand by your thighs, with your palms facing your body. "
#    "Keeping your arms straight, lift the dumbbells in front of you until they are parallel to the ground, then slowly lower them back down. Avoid swinging or using momentum, and focus on squeezing your shoulder muscles at the top of the movement. "
#    "You can also perform the exercise one arm at a time or with a resistance band. Start with a lighter weight and gradually increase as you become more comfortable with the exercise."
#    }


#exercise7 = {
#    "exName": "Single Front Lat Raises", 
#    "muscleGroups": "Deltoids | Traps | Lats",
#    "repFalsePic": "./AIWorkoutAssistant/helpPictures/.png",
#    "repTruePic": "./AIWorkoutAssistant/helpPictures/.png",
#    "exerciseDesc": "Single Arm Front Lat raises are a front raise exercise that target one shoulder at a time. To perform the exercise, stand with your feet shoulder-width apart and hold a dumbbell in one hand by your thigh, "
#    "with your palm facing your body. Keeping your arm straight, lift the dumbbell in front of you until it is parallel to the ground, then slowly lower it back down. Keep your torso stable and avoid twisting or leaning to one side. "
#    "Focus on squeezing your shoulder muscle at the top of the movement and maintain control throughout the exercise. You can perform the same number of reps on each arm or alternate arms between sets. "
#    "Using a lighter weight can help you maintain proper form and prevent injury."
#    }

exercise8 = {
    "exName": "Goblet Squats", 
    "muscleGroups": "Quads | Calves | Glutes | Arms | Lower Back | Grip Strength",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/gobletSquatFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/gobletSquatTrue.png",
    "exerciseDesc": "Goblet squats target the lower body, including the quadriceps, hamstrings, glutes, and calves, as well as the core muscles. To perform the exercise, hold a dumbbell or kettlebell with both hands at chest height, "
    "with your elbows pointing down and your feet shoulder-width apart. Keeping your chest up and your core engaged, lower your body by bending your knees and pushing your hips back, as if sitting in a chair. "
    "Keep your knees in line with your toes and your weight on your heels. Stop when your thighs are parallel to the ground, then push through your heels to lift your body back up to the starting position. "
    "Avoid arching your back or rounding your shoulders. Start with a lighter weight and gradually increase as you become more comfortable with the exercise."
    }


exercise9 = {
    "exName": "Shoulder Press", 
    "muscleGroups": "Deltoids | Traps | Triceps | Chest",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/shoulderPressFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/shoulderPressTrue.png",
    "exerciseDesc": "The Shoulder Press is a weightlifting exercise that targets the shoulders, triceps, and upper back muscles. "
    "To perform the exercise, stand with your feet shoulder-width apart and hold a barbell or dumbbells at shoulder level with palms facing forward. "
    "Press the weight overhead by straightening your arms and lifting the weight until your arms are fully extended. "
    "Slowly lower the weight back down to the starting position at your shoulders. It is important to avoid leaning or arching your back, as this can cause injury. "
    "Keep your core engaged and focus on maintaining good posture throughout the movement. Start with a lighter weight and gradually increase as you become more comfortable with the exercise."
    }

exercise10 = {
    "exName": "Single Arm Shoulder Press", 
    "muscleGroups": "Deltoids | Traps | Triceps | Chest",
    "repFalsePic": "./AIWorkoutAssistant/helpPictures/singleArmShoulderPressFalse.png",
    "repTruePic": "./AIWorkoutAssistant/helpPictures/singleArmShoulderPressTrue.png",
    "exerciseDesc": "Single arm shoulder press is similar to the regular shoulder press, but performed one arm at a time. Hold a dumbbell in one hand at shoulder level with your palm facing forward. "
    "Press the weight overhead by straightening your arm and lifting the weight until your arm is fully extended. "
    "Slowly lower the weight back down to the starting position at your shoulder and repeat on the other arm. This exercise targets the shoulders, triceps, and upper back muscles. "
    "To maintain proper posture, engage your core and keep your back straight throughout the exercise. Avoid leaning or tilting to one side, and ensure that your shoulders are level. "
    "You can also try the seated or standing variations of the exercise for different muscle activation."}

#clearTable(conn, clearExerciseTable=True)
#createTable(conn, dataBases[1][0])
##print(addIntoTable(conn, dataBases[1][1], exercise0))
##print(addIntoTable(conn, dataBases[1][1], exercise1))
#print(addIntoTable(conn, dataBases[1][1], exercise2))
#print(addIntoTable(conn, dataBases[1][1], exercise3))
#print(addIntoTable(conn, dataBases[1][1], exercise4))
#print(addIntoTable(conn, dataBases[1][1], exercise5))
##print(addIntoTable(conn, dataBases[1][1], exercise6))
##print(addIntoTable(conn, dataBases[1][1], exercise7))
#print(addIntoTable(conn, dataBases[1][1], exercise8))
#print(addIntoTable(conn, dataBases[1][1], exercise9))
#print(addIntoTable(conn, dataBases[1][1], exercise10))
#print(conn.tables())

#query: list = selectFromTable(conn, dataBases[1][1], colNum=5)
#for x in query:
#    print(x)


# 
#print(QDate().currentDate().toString("yyyy:MM:dd"))
#WorkoutDataDicts0 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Abductor Leg Raises",
#    "setCount": 2,
#    "repCount": 15
# }
#WorkoutDataDicts1 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Shoulder Press",
#    "setCount": 4,
#    "repCount": 12
# }
#WorkoutDataDicts2 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Bicep Curls",
#    "setCount": 6,
#    "repCount": 10
# }
#WorkoutDataDicts3 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Single Arm Bicep Curls",
#    "setCount": 3,
#    "repCount": 8
# }
#WorkoutDataDicts4 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Deltoid Arm Raises",
#    "setCount": 3,
#    "repCount": 10
# }
#WorkoutDataDicts5 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Single Arm Deltoid Raises",
#    "setCount": 3,
#    "repCount": 4
# }
#WorkoutDataDicts6 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Front Lat Raises",
#    "setCount": 4,
#    "repCount": 10
# }
#WorkoutDataDicts7 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Single Front Lat Raises",
#    "setCount": 1,
#    "repCount": 5
# }
#WorkoutDataDicts8 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "GGoblet Squats",
#    "setCount": 1,
#    "repCount": 3
# }
#WorkoutDataDicts9 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Shoulder Press",
#    "setCount": 4,
#    "repCount": 8
# }
#WorkoutDataDicts10 = {
#    "userName": "JJ01",
#    "dateID": QDate().currentDate().toString("dd/MM/yyyy"),
#    "exName": "Single Arm Shoulder Press",
#    "setCount": 1,
#    "repCount": 6
# }

#clearTable(conn, clearWorkoutDataTable=True)
#createTable(conn, dataBases[2][0])
#print(conn.tables()) 

#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts0))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts1))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts2))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts3))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts4))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts5))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts6))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts7))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts8))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts9))
#print(addIntoTable(conn, dataBases[2][1], WorkoutDataDicts10))

#query: list = selectFromTable(conn, dataBases[2][1], colNum=6)
#for x in query:
#    print(x)

#input()
#"""